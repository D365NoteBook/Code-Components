/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./TimeWindowPicker/components/DateAndTimeWindowPicker.tsx":
/*!*****************************************************************!*\
  !*** ./TimeWindowPicker/components/DateAndTimeWindowPicker.tsx ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   DateAndTimeRangePicker: () => (/* binding */ DateAndTimeRangePicker)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nvar HourFormat;\n(function (HourFormat) {\n  HourFormat[HourFormat[\"Hour24\"] = 0] = \"Hour24\";\n  HourFormat[HourFormat[\"Hour12\"] = 1] = \"Hour12\";\n})(HourFormat || (HourFormat = {}));\nvar stackStyles = {\n  root: {\n    // width: '100%',\n    ':hover': {\n      border: '1px solid rgb(102, 102, 102)'\n    }\n  }\n};\nvar dropdownStyles = {\n  dropdown: {\n    minWidth: 150,\n    textAlign: 'left'\n  },\n  title: {\n    borderStyle: 'none'\n  }\n};\nvar generateTimeList = (start, increment, hourFormat) => {\n  var timeStrings = [];\n  var startTime = new Date(\"1970-01-01T\".concat(start, \":00\"));\n  var timeList = [new Date(startTime.getTime())];\n  var flag = true;\n  while (flag) {\n    startTime.setMinutes(startTime.getMinutes() + increment);\n    if (startTime.getDate() > 1) {\n      flag = false;\n      break;\n    }\n    timeList.push(new Date(startTime.getTime()));\n  }\n  if (hourFormat === HourFormat.Hour24) {\n    timeStrings = timeList.map(time => {\n      var hours = time.getHours().toString().padStart(2, '0');\n      var minutes = time.getMinutes().toString().padStart(2, '0');\n      return \"\".concat(hours, \":\").concat(minutes);\n    });\n  }\n  if (hourFormat === HourFormat.Hour12) {\n    timeStrings = timeList.map(time => {\n      var hours = time.getHours();\n      var minutes = time.getMinutes().toString().padStart(2, '0');\n      var period = hours >= 12 ? 'PM' : 'AM';\n      hours = hours % 12;\n      hours = hours ? hours : 12;\n      return \"\".concat(hours.toString().padStart(2, '0'), \":\").concat(minutes, \" \").concat(period);\n    });\n  }\n  return timeStrings;\n};\nvar onRenderTitleFrom = options => {\n  if (options && options.length > 0) {\n    var option = options[0];\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      style: {\n        fontWeight: 600\n      }\n    }, \"From: \".concat(option.text)));\n  }\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null);\n};\nvar onRenderTitleTo = options => {\n  if (options && options.length > 0) {\n    var option = options[0];\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      style: {\n        fontWeight: 600\n      }\n    }, \"To: \".concat(option.text)));\n  }\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null);\n};\nvar getTimeString12HourFormat = time => {\n  var hours = time.getHours();\n  var minutes = time.getMinutes().toString().padStart(2, '0');\n  var period = hours >= 12 ? 'PM' : 'AM';\n  hours = hours % 12;\n  hours = hours ? hours : 12;\n  return \"\".concat(hours.toString().padStart(2, '0'), \":\").concat(minutes, \" \").concat(period);\n};\nvar getTimeString24HourFormat = time => {\n  var hours = time.getHours().toString().padStart(2, '0');\n  var minutes = time.getMinutes().toString().padStart(2, '0');\n  return \"\".concat(hours, \":\").concat(minutes);\n};\nvar DateAndTimeRangePicker = props => {\n  var {\n    increment,\n    hourFormat\n  } = props;\n  var [datePickerDate, setDatePickerDate] = react__WEBPACK_IMPORTED_MODULE_0__.useState(props.timeFrom);\n  var [timeFrom, setTimeFrom] = react__WEBPACK_IMPORTED_MODULE_0__.useState('');\n  var [timeTo, setTimeTo] = react__WEBPACK_IMPORTED_MODULE_0__.useState('');\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    var setDefaultTime = (timeFrom, timeTo) => {\n      if (hourFormat === HourFormat.Hour24) {\n        setTimeFrom(getTimeString24HourFormat(timeFrom));\n        setTimeTo(getTimeString24HourFormat(timeTo));\n      }\n      if (hourFormat === HourFormat.Hour12) {\n        setTimeFrom(getTimeString12HourFormat(timeFrom));\n        setTimeTo(getTimeString12HourFormat(timeTo));\n      }\n    };\n    setDefaultTime(props.timeFrom, props.timeTo);\n  }, []);\n  var options = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {\n    var timeList = generateTimeList('00:00', increment, hourFormat);\n    var dropdownOptions = timeList.map(time => ({\n      key: time,\n      text: time\n    }));\n    return dropdownOptions;\n  }, []);\n  var onSelectDate = selectedDate => {\n    if (selectedDate) {\n      var snappedTimeFrom = selectedDate;\n      var snappedTimeTo = selectedDate;\n      setDatePickerDate(selectedDate);\n      if (timeFrom) {\n        snappedTimeFrom = new Date(\"\".concat(selectedDate.toDateString(), \" \").concat(timeFrom));\n      }\n      if (timeTo) {\n        snappedTimeTo = new Date(\"\".concat(selectedDate.toDateString(), \" \").concat(timeTo));\n      }\n      props.notifyOutputChanged(snappedTimeFrom, snappedTimeTo, true);\n    }\n  };\n  var onChangeTimeFrom = (event, option, index) => {\n    if (option) {\n      setTimeFrom(option.text);\n      var dateFrom = new Date(\"\".concat(datePickerDate.toDateString(), \" \").concat(option.text));\n      var dateTo = new Date(\"\".concat(datePickerDate.toDateString(), \" \").concat(timeTo));\n      if (dateFrom > dateTo) {\n        dateTo = new Date(\"\".concat(datePickerDate.toDateString(), \" \").concat(option.text));\n        dateTo.setMinutes(dateTo.getMinutes() + 30);\n        if (hourFormat === HourFormat.Hour24) {\n          // setTimeFrom(getTimeString24HourFormat(timeFrom));\n          setTimeTo(getTimeString24HourFormat(dateTo));\n        }\n        if (hourFormat === HourFormat.Hour12) {\n          // setTimeFrom(getTimeString12HourFormat(timeFrom));\n          setTimeTo(getTimeString12HourFormat(dateTo));\n        }\n        // setTimeTo(option.text);\n      }\n      props.notifyOutputChanged(dateFrom, dateTo, true);\n    }\n  };\n  var onChangeTimeTo = (event, option, index) => {\n    if (option) {\n      setTimeTo(option.text);\n      var dateFrom = new Date(\"\".concat(datePickerDate.toDateString(), \" \").concat(timeFrom));\n      var dateTo = new Date(\"\".concat(datePickerDate.toDateString(), \" \").concat(option.text));\n      var isTimeWindowValid = dateFrom < dateTo;\n      props.notifyOutputChanged(dateFrom, dateTo, isTimeWindowValid);\n    }\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {\n    grow: true\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {\n    horizontal: true,\n    verticalAlign: 'center',\n    grow: true,\n    wrap: true,\n    styles: stackStyles\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack.Item, {\n    grow: true\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.DatePicker, {\n    className: \"customDatePicker\",\n    placeholder: \"Select a date...\",\n    formatDate: date => {\n      if (date) {\n        return date.toLocaleDateString();\n      }\n      return '';\n    },\n    value: datePickerDate,\n    onSelectDate: onSelectDate,\n    ariaLabel: \"Date picker\",\n    styles: {\n      root: {\n        minWidth: 160,\n        width: '100%',\n        paddingRight: 5,\n        paddingTop: 5\n      },\n      textField: {\n        fontWeight: 600\n      }\n    }\n  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack.Item, {\n    grow: true\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {\n    grow: true,\n    horizontal: true,\n    wrap: true\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack.Item, {\n    grow: true\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Dropdown, {\n    placeholder: \"From...\",\n    selectedKey: timeFrom,\n    options: options,\n    styles: dropdownStyles,\n    onRenderCaretDown: () => {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Icon, {\n        iconName: \"Clock\"\n      });\n    },\n    onRenderTitle: onRenderTitleFrom,\n    calloutProps: {\n      calloutMaxHeight: 300\n    },\n    onChange: onChangeTimeFrom\n  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack.Item, {\n    grow: true\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Dropdown, {\n    placeholder: \"To...\",\n    selectedKey: timeTo,\n    options: options,\n    styles: dropdownStyles,\n    onRenderCaretDown: () => {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Icon, {\n        iconName: \"Clock\"\n      });\n    },\n    onRenderTitle: onRenderTitleTo,\n    calloutProps: {\n      calloutMaxHeight: 300\n    },\n    onChange: onChangeTimeTo\n  }))))));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./TimeWindowPicker/components/DateAndTimeWindowPicker.tsx?");

/***/ }),

/***/ "./TimeWindowPicker/index.ts":
/*!***********************************!*\
  !*** ./TimeWindowPicker/index.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   TimeWindowPicker: () => (/* binding */ TimeWindowPicker)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_DateAndTimeWindowPicker__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/DateAndTimeWindowPicker */ \"./TimeWindowPicker/components/DateAndTimeWindowPicker.tsx\");\n\n\nclass TimeWindowPicker {\n  /**\r\n   * Empty constructor.\r\n   */\n  constructor() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  init(context, notifyOutputChanged, state) {\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._context = context;\n  }\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  updateView(context) {\n    var timeFrom = this.correctTimeZoneForD365(context.parameters.timeFrom.raw || new Date());\n    var timeTo = this.correctTimeZoneForD365(context.parameters.timeTo.raw || new Date());\n    var increament = context.parameters.increment.raw || 30;\n    var hourFormat = parseInt(context.parameters.hourFormat.raw) || 0;\n    // const dateFrom = new Date(2024, 3, 11, 14, 0);\n    // const dateTo = new Date(2024, 3, 11, 14, 0);\n    var props = {\n      timeFrom: timeFrom,\n      timeTo: timeTo,\n      increment: increament,\n      hourFormat: hourFormat,\n      notifyOutputChanged: this.notifyOutputChanged.bind(this)\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_DateAndTimeWindowPicker__WEBPACK_IMPORTED_MODULE_1__.DateAndTimeRangePicker, props);\n  }\n  correctTimeZoneForD365(date) {\n    if (date === null) return null;\n    var TIMEZONE_INDEPENDENT_BEHAVIOR = 3;\n    var fieldBehavior = this._context.parameters.timeFrom.attributes.Behavior;\n    var timezoneOffsetInMinutes = fieldBehavior === TIMEZONE_INDEPENDENT_BEHAVIOR ? 0 : this._context.userSettings.getTimeZoneOffsetMinutes(date);\n    var newDate = new Date(date).setMinutes(date.getMinutes() + date.getTimezoneOffset() + timezoneOffsetInMinutes);\n    return new Date(newDate);\n  }\n  notifyOutputChanged(timeFrom, timeTo, isTimeWindowValid) {\n    this._timeFrom = timeFrom;\n    this._timeTo = timeTo;\n    this._isTimeWindowValid = isTimeWindowValid;\n    this._notifyOutputChanged();\n  }\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\r\n   */\n  getOutputs() {\n    return {\n      timeFrom: this._timeFrom,\n      timeTo: this._timeTo,\n      isTimeWindowValid: this._isTimeWindowValid\n    };\n  }\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./TimeWindowPicker/index.ts?");

/***/ }),

/***/ "@fluentui/react":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./TimeWindowPicker/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('DNB.TimeWindowPicker', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TimeWindowPicker);
} else {
	var DNB = DNB || {};
	DNB.TimeWindowPicker = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TimeWindowPicker;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}